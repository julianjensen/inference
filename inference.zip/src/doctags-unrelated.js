/** ******************************************************************************************************************
 * @file Describe what doctag-unrelated does.
 * @author Julian Jensen <jjdanois@gmail.com>
 * @since 1.0.0
 * @date 20-Jan-2018
 *********************************************************************************************************************/
"use strict";

export default function unassociated_tag( node, { comment, tags: { description, tags } } )
{

}
