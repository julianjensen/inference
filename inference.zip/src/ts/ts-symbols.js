/** ******************************************************************************************************************
 * @file Describe what ts-symbols does.
 * @author Julian Jensen <jjdanois@gmail.com>
 * @since 1.0.0
 * @date 17-Mar-2018
 *
 * libs needed:
 * lib.es6.d.ts
 * node.d.ts
 * dom.es6.generated.d.ts
 * esnext.promise.d.ts
 * inspector.d.ts
 * lib.es2017.intl.d.ts
 * lib.es2017.object.d.ts
 * lib.es2017.sharedmemory.d.ts
 * lib.es2017.string.d.ts
 * lib.es2017.typedarray.d.ts
 * lib.esnext.asynciterable.d.ts
 * webworker.generated.d.ts
 *********************************************************************************************************************/
"use strict";

import { hide_parent, skeys } from "../utils";
import { inspect }            from "util";
import { SyntaxKind }         from "./ts-helpers";
import * as ts                from "typescript";
import {
    NodeFlags,
    ObjectFlags, SymbolFlags,
    TypeFlags
<<<<<<< HEAD
}                             from "../types";
import { type, nameOf }       from "typeofs";
import deep from "deep-eql";
=======
} from "../types";
import { type, nameOf } from "typeofs";
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

const
    optional = ( obj, check ) => {
        if ( !check ) return obj;

        obj.optional = true;
        return obj;
    },
    clean = o => {

        if ( !isObject( o ) ) return o;

        const no = {};

        Object.keys( o ).forEach( k => ( o[ k ] === null || o[ k ] === void 0 ) || ( no[ k ] = o[ k ] ) );

        return no;
    },
    declDupes = new WeakSet(),
    hide = ( obj, name, value ) => Object.defineProperty( obj, name, { enumerable: false, value } ),
    isObject = o => typeof o === 'object' && !Array.isArray( o ) && o !== null,
    isString = s => typeof s === 'string',
    isArray = a => Array.isArray( a ),
    keyCount = o => Object.keys( o ).length,
    $    = ( o, d = 2 ) => inspect( o,
        {
            depth:  typeof d === 'number' ? d : 2,
            colors: false,
            showHidden: false
        } ),
    seen = new Set(),
    uniq = arr => {
        const
            dest = [],
            eql = ( a, b ) => {
                const
                    akeys = Object.keys( a ).filter( k => k !== 'loc' && k !== 'flags' ).sort(),
                    bkeys = Object.keys( b ).filter( k => k !== 'loc' && k !== 'flags' ).sort();

                if ( akeys.length !== bkeys.length || !akeys.every( ak => bkeys.includes( ak ) ) ) return false;

                for ( const ak of akeys )
                {
                    const
                        av = a[ ak ],
                        bv = b[ ak ];

                    if ( isObject( av ) && isObject( bv ) && eql( av, bv ) ) continue;
                    else if ( isArray( av ) && isArray( bv ) && av.every( ( _av, i ) => eql( _av, bv[ i ] ) ) ) continue;
                    else if ( av === bv ) continue;

                    return false;
                }
            };

        arr.forEach( el => {
            delete el.loc;
            if ( !dest.find( d => deep( d, el ) ) )
                dest.push( el );
        } );

        return dest;
    },
    fixKeyword = s => isString( s ) && /^\s*[A-Z][a-z]+Keyword\s*$/.test( s ) ? s.replace( /^\s*(.*)Keyword\s*$/, '$1' ).toLowerCase() : s;

const topLevelNames = [];

function elevate( obj )
{
    // if ( !isObject( obj ) ) return obj;

    // if ( isArray( obj.template ) ) obj.template = fix_raw_templates( obj.template );

    // if ( isObject( obj.name ) && isArray( obj.name.template ) ) obj.name.template = fix_raw_templates( obj.name.template );
    //
    // if ( isArray( obj.types ) )
    //     return obj.types.map( elevate );

    if ( !isObject( obj ) || keyCount( obj ) !== 1 ) return obj;

    if ( isString( obj.typeName ) )
        return obj.typeName;
    else if ( isString( obj.type ) )
        return obj.type;

    return obj;
}

function get_name( sym )
{
    try
    {
        let name = sym.name || sym.escapedName || sym._escapedName;

        name = `${name}`;

        return name.startsWith( '"' ) ? name.substring( 1, name.length - 1 ) : name;
    }
    catch ( err )
    {
        console.error( err );
        process.exit( 1 );
    }
}

let typeChecker,
    file;

/**
 * @param {object} _file
 */
export function walk_symbols( _file )
{
    file        = _file;
    typeChecker = _file.typeChecker;
<<<<<<< HEAD

    const r = sym_walk( _file.ast, {} );
    r.topLevelNames = topLevelNames.sort();

    return r;
=======
    return sym_walk( _file.ast, {} );
}

function type_in_mapped_type( node )
{
    while ( node )
    {
        if ( node.kind === SyntaxKind.MappedType ) return true;
        node = node.parent;
    }

    return false;
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
}

function type_in_mapped_type( node )
{
    while ( node )
    {
        if ( node.kind === SyntaxKind.MappedType ) return true;
        node = node.parent;
    }

    return false;
}

// function get_type_of_node( sym, node )
// {
//     let t = typeChecker.getTypeOfSymbolAtLocation( sym, node );
//     delete t.symbol;
//     delete t.bindDiagnostics;
//     delete t.parent;
//     delete t.checker;
//     // t = hide_parent( t );
//     if ( t.objectFlags ) t.objectFlags = ObjectFlags.create( t.objectFlags );
//     if ( t.flags ) t.flags = TypeFlags.create( t.flags );
//     return t;
// }

function module_name( name )
{
    if ( name.kind === SyntaxKind.Identifier )
        return name.escapedText;
    else if ( name.kind === SyntaxKind.StringLiteral )
        return name.text;

    return SyntaxKind[ name.kind ];
}

function tmp_name( sym, id = false )
{
    return sym.escapedName + ( id && sym.id ? ' (' + sym.id + ')' : '' );
}

function ident( node, mode = 'tiny' )
{
    if ( !node ) return ' NO NODE';

    if ( !Reflect.has( node, 'escapedName' ) )
    {
        if ( !Reflect.has( node, 'symbol' ) ) return '';
        node = node.symbol;
    }

    if ( !node.id ) return `${node.LOCAL || "ALIEN"}: NO ID ON ${node.escapedName || 'AND NO NAME'} [ ${Object.keys( node ).join( ', ' )} ]`;

    const pid = node.parent && node.parent.id ? `<${node.parent.id}` : '';

    switch ( mode )
    {
        case 'name':    return node.id || node.escapedName;
        case 'tiny':    return ' ' + ( node.id || node.escapedName ) + pid;
        case 'short':    return ' (ref: ' + node.id + pid + ')';
        default:
        case 'long':    return ` ${node.escapedName} (${node.id}${pid})`;
    }
}

function export_specifier( ex )
{
    let prop = ex.propertyName.escapedText;

    if ( ex.name && ex.name.escapedText !== prop  ) prop += ' as ' + ex.name.escapedText;

    return prop;
}

function list_heritage( nodes )
{
    if ( !nodes || !nodes.length ) return null;

    if ( nodes.length === 1 && nodes[ 0 ].kind === SyntaxKind.HeritageClause )
        return list_heritage( nodes[ 0 ].types );

    return nodes.map( h => {
        const
            out = {};

        if ( h.kind === SyntaxKind.ExpressionWithTypeArguments )
        {
            if ( h.expression.kind === SyntaxKind.Identifier )
                out.name = h.expression.escapedText;
            else
                out.name = "not identifier but " + SyntaxKind[ h.expression.kind ];

            if ( h.typeArguments && h.typeArguments.length )
                out.typeArguments = h.typeArguments.map( get_type_name );
        }
        else // if ( h.kind === SyntaxKind.HeritageClause )
            out.name = "not expression with type arguments but " + SyntaxKind[ h.kind ] + ` -> [ ${Object.keys( h )} ]`;

        return out;
    } );
}

function module_name( name )
{
    if ( name.kind === SyntaxKind.Identifier )
        return name.escapedText;
    else if ( name.kind === SyntaxKind.StringLiteral )
        return name.text;

    return SyntaxKind[ name.kind ];
}

function tmp_name( sym )
{
    return sym.escapedName; // + '_@' + sym.id;
}

function export_specifier( ex )
{
    let prop = ex.propertyName.escapedText;

    if ( ex.name && ex.name.escapedText !== prop  ) prop += ' as ' + ex.name.escapedText;

    return prop;
}

function list_heritage( nodes )
{
    if ( !nodes || !nodes.length ) return null;

    if ( nodes.length === 1 && nodes[ 0 ].kind === SyntaxKind.HeritageClause )
        return list_heritage( nodes[ 0 ].types );

    return nodes.map( h => {
        const
            out = {};

        if ( h.kind === SyntaxKind.ExpressionWithTypeArguments )
        {
            if ( h.expression.kind === SyntaxKind.Identifier )
                out.name = h.expression.escapedText;
            else
                out.name = "not identifier but " + SyntaxKind[ h.expression.kind ];

            if ( h.typeArguments && h.typeArguments.length )
                out.typeArguments = h.typeArguments.map( get_type_name )
        }
        else // if ( h.kind === SyntaxKind.HeritageClause )
            out.name = "not expression with type arguments but " + SyntaxKind[ h.kind ] + ` -> [ ${Object.keys( h )} ]`;

        return out;
    } );
}

/**
 * @param {ts.Node} node
 * @param {object} [table={}]
 */
export function sym_walk( node, table = {} )
{
    const isInterface = node && node.kind && node.kind === SyntaxKind.InterfaceDeclaration;

    if ( isInterface && seen.has( get_name( node.symbol ) ) ) return;
    else if ( isInterface ) seen.add( get_name( node.symbol ) );

    /********************************************************************************************************************
     * File name info
     ********************************************************************************************************************/

    if ( node.fileName )
    {
        table = table[ node.fileName ] = {
            kind: SyntaxKind[ node.kind ]
        };
<<<<<<< HEAD
    }
=======
        // console.log( `\n${SyntaxKind[ node.kind ]} of "${node.fileName}" ->` );
    }
    // else if ( ![ SyntaxKind.VariableStatement, SyntaxKind.VariableDeclarationList ].includes( node.kind ) )
    //     console.log( `\n${SyntaxKind[ node.kind ]} ->` );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    /********************************************************************************************************************
     * Modules and namespaces
     ********************************************************************************************************************/

    if ( node.kind === SyntaxKind.ModuleDeclaration )
    {
        const tmp = table[ module_name( node.name ) ] = show_sym( node.symbol );
        delete tmp.name;
<<<<<<< HEAD
=======
        // if ( tmp.name.startsWith( '"' ) ) tmp.name = tmp.name.replace( /^"(.*)"$/, '$1' );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

        // MAYBE DUPE
        // tmp.moduleMembers = node.body.statements.map( n => sym_walk( n, {} ) );
        return table;
    }
<<<<<<< HEAD
=======

    // if ( node.kind === SyntaxKind.ExportDeclaration )
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    /********************************************************************************************************************
     * Locals
     ********************************************************************************************************************/

    if ( node.localSymbol )
<<<<<<< HEAD
        table[ tmp_name( node.localSymbol ) ] = show_sym( node.localSymbol );
=======
    {
        table[ tmp_name( node.localSymbol ) ] = show_sym( node.localSymbol );
        // console.log( `localSymbol:`, $( show_sym( node.localSymbol ), 10 ) );
    }
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    // MAYBE DUPE
    if ( node.locals )
    {
        table.locals = [ ...node.locals.values() ].map( show_sym );
<<<<<<< HEAD
        table.locals.forEach( s => topLevelNames.push( s.name ) );
=======
        // console.log( `locals:`, $( [ ...node.locals.values() ].map( show_sym ), 10 ) );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    }

    /********************************************************************************************************************
     * Variable declaration
     ********************************************************************************************************************/

    if ( node.kind === SyntaxKind.VariableDeclaration )
    {
<<<<<<< HEAD
=======
        // const v = show_sym( node.symbol );

        // const flags = node.symbol.flags ? ', flags: ' + SymbolFlags.create( node.symbol.flags ).toString() : '';
        // console.log( `${get_name( node.symbol )}: ${add_types( node.type )}${flags}` );

>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
        const varDef = {
            flags: node.symbol.flags ? SymbolFlags.create( node.symbol.flags ).toString() : '',
            types: add_types( node.type )
        };
<<<<<<< HEAD
=======

        if ( table[ tmp_name( node.symbol ) ] )
        {
            const tmp = table[ tmp_name( node.symbol ) ];

            if ( Array.isArray( tmp ) )
                tmp.push( varDef );
            else
                table[ tmp_name( node.symbol ) ] = [ tmp, varDef ];
        }
        else
            table[ tmp_name( node.symbol ) ] = varDef;
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

        if ( table[ tmp_name( node.symbol ) ] )
        {
            const tmp = table[ tmp_name( node.symbol ) ];

            if ( Array.isArray( tmp ) )
                tmp.push( varDef );
            else
                table[ tmp_name( node.symbol ) ] = [ tmp, varDef ];
        }
        else
            table[ tmp_name( node.symbol ) ] = varDef;
    }

    /********************************************************************************************************************
     * Symbol
     ********************************************************************************************************************/

    else if ( node.symbol )
    {
<<<<<<< HEAD
        // const tmp = {
        //
        // };
=======
        const tmp = {

        };

        // console.log( `Symbol name: ${get_name( node.symbol )}` );
        // if ( node.symbol.declarations ) console.log( '    declarations:', $( node.symbol.declarations.map( decl => SyntaxKind[ decl.kind ] ), 10 ) );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

        // MAYBE DUPE
        // if ( node.symbol.declarations ) tmp.declarations = node.symbol.declarations.map( decl => SyntaxKind[ decl.kind ] );

<<<<<<< HEAD
        // tmp.internal = show_sym( node.symbol, node );

        if ( !table.internal ) table.internal = [];

        table.internal.push( show_sym( node.symbol, node, true ) );
=======
        const internal = show_sym( node.symbol, node );
        tmp.internal = internal;
        // console.log( $( internal, 10 ) );

        table[ tmp_name( node.symbol ) ] = tmp;
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    }

    /********************************************************************************************************************
     * Recursions
     ********************************************************************************************************************/

    else if ( node.kind === SyntaxKind.VariableStatement )
    {
        if ( !table.__vars ) table.__vars = {};

        sym_walk( node.declarationList, table );
    }
    else if ( node.kind === SyntaxKind.VariableDeclarationList )
    {
        if ( !table.__vars ) table.__vars = {};
<<<<<<< HEAD

        node.declarations.forEach( sym => sym_walk( sym, table.__vars ) );
    }

=======

        node.declarations.forEach( sym => sym_walk( sym, table.__vars ) );
    }

>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    // MAYBE DUPE
    // if ( Array.isArray( node.statements ) )
    //     node.statements.forEach( sym => sym_walk( sym, table ) );

    return table;
}

function show_sym( sym, noExports = false )
{
    if ( !sym ) return null;

    const
        r = { name: disambiguate( get_name( sym ) ) }, // , id: sym.id },
        d = decls( sym );

    if ( sym.flags )
    {
<<<<<<< HEAD
        const flags = SymbolFlags.create( sym.flags & ~SymbolFlags.Transient ).toString();
=======
        const flags = SymbolFlags.create( sym.flags ).toString();

        if ( flags ) r.flags = flags;
    }

    if ( sym.valueDeclaration )
        r.valueDeclaration = get_decl( sym.valueDeclaration );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

        // if ( flags && flags !== 'Transient' ) r.flags = flags;
        if ( flags ) r.flags = flags;
    }

    if ( sym.valueDeclaration && !sym.declarations.includes( sym.valueDeclaration ) )
        r.valueDeclaration = get_decl( sym.valueDeclaration );

    if ( d )
    {
        d.forEach( decl => {
            if ( isObject( decl.type ) && typeof decl.type.typeName === 'string' && Object.keys( decl.type ).length === 1 )
                decl.type = decl.type.typeName;
        } );
        r.decls = d;
    }

    if ( sym.members && sym.members.size )
    {
        let m = from_sym( sym.members );

        set_members( m, r );
        // if ( isArray( m ) ) m = m.filter( x => x );
        //
        // if ( m && ( !isArray( m ) ||  m.length ) ) r.members = m;
    }

    if ( sym.exports && sym.exports.size && !noExports )
        r.exports = from_sym( sym.exports );

    if ( sym.localSymbol )
        r.localSymbol = show_sym( sym.localSymbol );

    if ( sym.exportSymbol )
<<<<<<< HEAD
    {
        const tmp = show_sym( sym.exportSymbol );

        if ( r.name !== tmp.name || ( tmp.decls && tmp.decls.length ) )
            r.exportSymbol = tmp;
        else if ( tmp.members )
            set_members( tmp.members, r );
    }

    hide( r, 'node', sym );

    return r;
}

function set_members( members, r )
{
    const mem = _m => { r.members = _m; return r; };

    if ( !members ) return mem( members );

    if ( !isArray( members ) ) return mem( members );

    const m = members.filter( x => !!x );

    if ( m.length ) return mem( m );
=======
        r.exportSymbol = show_sym( sym.exportSymbol );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    return r;
}

function from_sym( syms )
{
    if ( !syms.size ) return [];

    return [ ...syms.values() ].map( show_sym );
}

function decls( sym )
{
    if ( !sym || !sym.declarations || !sym.declarations.length ) return null;

    const r = sym.declarations.filter( d => !declDupes.has( d ) ).map( get_decl );

    return r.length ? uniq( r ) : null;
}

<<<<<<< HEAD
// function type_literal_as_string( tl, short = true )
// {
//     const members = tl && tl.members;
//
//     if ( !tl ) return "Object";
//     if ( !members ) return 'wassup: ' + typeof tl; // Object.keys( tl ).join( ', ' ); // JSON.stringify( tl );
//
//     return '{ ' + members.map( m => m.valueDeclaration ? m.valueDeclaration.decl : m.decls[ 0 ].decl ).join( short ? '; ' : ';\n' ) + ' }';
// }
=======
var tmp = {
    name: "__type",
    flags: "TypeLiteral",
    decls: [
        { loc: "80:90", decl: "TypeLiteral" }
        ],
    members: [
        {
            name: "__index",
            flags: "Signature",
            decls: [
                {
                    loc: "80:92",
                    decl: "[ x: string ]: PropertyDescriptor"
                }
                ]
        }
        ]
};

function type_literal_as_string( tl, short = true )
{
    const members = tl && tl.members;

    if ( !tl ) return "No fucking TL";
    if ( !members ) return JSON.stringify( tl );

    return '{ ' + members.map( m => m.valueDeclaration ? m.valueDeclaration.decl : m.decls[ 0 ].decl ).join( short ? '; ' : ';\n' ) + ' }';
}
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

function get_decl( decl )
{
    let [ lineNumber, offset ] = file.reporters.offset_to_line_offset( decl.pos ),
<<<<<<< HEAD
        declName               = `${decl.name && decl.name.escapedText || ''}`,
=======
        declName               = `${decl.name && decl.name.escapedText || 'noName'}`,
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
        // declName               = `${SyntaxKind[ decl.kind ]}`,
        typeName               = decl.type ? add_types( decl.type ) : '',
        heritage;

<<<<<<< HEAD
    declDupes.add( decl );

=======
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    if ( decl.heritageClauses )
        heritage = list_heritage( decl.heritageClauses );

    if ( decl.kind === SyntaxKind.IndexSignature )
    {
        declName = `[ ${decl.parameters.map( pretty ).join( ', ' )} ]`;
        typeName = get_type_name( decl.type );
    }
    else
    {
        declName += check_for_template( decl );
        // if ( decl.typeParameters )
        //     declName += type_parameters( decl.typeParameters );

        if ( decl.parameters )
        {
            if ( decl.parameters.length )
                declName = `${declName}( ${decl.parameters.map( pretty ).join( ', ' )} )`;
            else
                declName += '()';
        }
    }

    let flags = '';
    if ( decl.flags && !!( decl.flags & ~NodeFlags.Ambient ) )
        flags = ' [ ' + NodeFlags.create( decl.flags & ~NodeFlags.Ambient ).toString() + ' ]';

    if ( decl.kind === SyntaxKind.ExportSpecifier )
    {
        let propName = '<no prop name>';

<<<<<<< HEAD
        if ( Reflect.has( decl, 'propertyName' ) && type( decl.propertyName ) === 'object' && Reflect.has( decl, 'propertyName' ) )
            propName = decl.propertyName.escapedText;
        else if ( Reflect.has( decl, 'name' ) && type( decl.name ) === 'object' && Reflect.has( decl, 'name' ) )
=======
        if ( Reflect.has( decl, 'propertyName' ) && type( decl.propertyName ) === 'object' && Reflect.has( decl , 'propertyName' ) )
            propName = decl.propertyName.escapedText;
        else if ( Reflect.has( decl, 'name' ) && type( decl.name ) === 'object' && Reflect.has( decl , 'name' ) )
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
            propName = decl.name.escapedText;

        typeName = propName;
        // return `@${lineNumber + 1}:${offset}${flags} ${propName}` ;
    }
    // else if ( decl.kind === SyntaxKind.IndexSignature )
    // {
    //     declName = `[ ${decl.parameters.map( pretty ).join( ', ' )} ]`;
    //     typeName = get_type_name( decl.type );
    // }
    // else
    // {
    //     declName += check_for_template( decl );
    //     // if ( decl.typeParameters )
    //     //     declName += type_parameters( decl.typeParameters );
    //
    //     if ( decl.parameters )
    //     {
    //         if ( decl.parameters.length )
    //             declName = `${declName}( ${decl.parameters.map( pretty ).join( ', ' )} )`;
    //         else
    //             declName += '()';
    //     }
    // }

    if ( type( typeName ) === 'object' )
    {
        const r = { name: declName, type: typeName, loc: `@${lineNumber + 1}:${offset}` };
<<<<<<< HEAD
        if ( flags && flags !== NodeFlags.Ambient ) r.flags = flags;
=======
        if ( flags ) r.flags = flags;
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    }

    // NEW STUFF OLD STUFF
    const dd = {
        loc: `${lineNumber + 1}:${offset}`,
<<<<<<< HEAD
        decl: declName + ( type( typeName ) !== 'object' && typeName ? ': ' + typeName : '' ),
    };

    let _type = decl.type ? add_raw_types( decl.type ) : '';
    if ( _type ) _type = elevate( _type );
    if ( _type ) dd.type = _type;

    hide( dd, 'node', decl );

    if ( decl.parameters )
        func_type_info( decl, dd );

    if ( heritage )
        dd.heritage = heritage;
    // if ( flags )
    // {
    //     const f = `${flags}`;
    //
    //     if ( f !== 'Transient' )
    //         dd.flags = f;
    // }

    dd.kind = SyntaxKind[ decl.kind ];
    // dd.hasSymbol = ( decl.symbol ? ident( decl, 'long' ) : 'no' ).trim();
=======
        decl: declName + ( type( typeName ) !== 'object' && typeName ? ': ' + typeName : '' )
    };

    if ( heritage )
        dd.heritage = heritage;
    if ( flags )
        dd.flags = `${flags}`;

    dd.kind = SyntaxKind[ decl.kind ];
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    return dd;

    // TO HERE

    // return `@${lineNumber + 1}:${offset}${flags} ` + declName + ( typeName ? ': ' + typeName : '' );
}

function pretty( decl )
{
    let str = '';

    if ( decl.name )
        str += ( decl.dotDotDotToken ? '...' : '' ) + decl.name.escapedText + ( decl.questionToken ? '?' : '' );
    else
        str += 'anon';

    // let flags;
    // if ( decl.symbol && decl.symbol.flags )
    // {
    //     flags = ' [ ' + SymbolFlags.create( decl.symbol.flags ).toString() + ' ]';
    //     if ( flags === ' [ FunctionScopedVariable ]' ) flags = '';
    // }

    // return str + ': ' + add_types( decl.type ) + flags;
    return str + ': ' + add_types( decl.type );
}

/**
 * @param {ts.Node} type
 * @return {string}
 */
function add_types( type )
{
    // if ( !type ) return '<missing> ' + new Error().stack.split( /\r?\n/ ).slice( 1, 4 ).join( ' | ' );

    let t;

    if ( type.kind === SyntaxKind.Identifier )
<<<<<<< HEAD
        return type.escapedText + ident( type );

    else if ( type.kind === SyntaxKind.ParenthesizedType )
        return `( ${add_types( type.type )} )`;

    else if ( type.kind === SyntaxKind.TypePredicate )
        return `${type.parameterName.escapedText} ${ident( type.parameterName )}is ${add_types( type.type )}`;

    else if ( type.kind === SyntaxKind.TypeReference )
        return add_types( type.typeName ) + check_for_template( type );

=======
        return type.escapedText;
    else if ( type.kind === SyntaxKind.ParenthesizedType )
        return `( ${add_types( type.type )} )`;
    else if ( type.kind === SyntaxKind.TypePredicate )
        return `${type.parameterName.escapedText} is ${add_types( type.type )}`;
    else if ( type.kind === SyntaxKind.TypeReference )
        return add_types( type.typeName ) + check_for_template( type );
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    else if ( type.kind === SyntaxKind.QualifiedName )
        return qual_name( type );

    else if ( type.kind === SyntaxKind.FunctionType )
        return func_type( type );

    else if ( type.kind === SyntaxKind.UnionType )
        return type.types.map( add_types ).join( ' | ' );
<<<<<<< HEAD

=======
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    else if ( type.kind === SyntaxKind.IntersectionType )
        return type.types.map( add_types ).join( ' & ' );

    else if ( type.kind === SyntaxKind.MappedType )
        return `{ [ ${add_types( type.typeParameter )} ]${type.questionToken ? '?' : ''}: ${get_type_name( type.type )} }`;


    else if ( type.kind === SyntaxKind.LiteralType )
    {
        switch ( type.literal.kind )
        {
            case SyntaxKind.StringLiteral:
<<<<<<< HEAD
                return `'${type.literal.text}' ${ident( type )}`;
=======
                return `'${type.literal.text}'`;
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

            case SyntaxKind.NumericLiteral:
                return type.literal.text + ident( type );

            case SyntaxKind.TrueKeyword:
                return 'true' + ident( type );

            case SyntaxKind.FalseKeyword:
                return 'false' + ident( type );

            case SyntaxKind.TrueKeyword:
                return 'true';

            case SyntaxKind.FalseKeyword:
                return 'false';

            default:
                return `Unknown literal "${SyntaxKind[ type.literal.kind ]}" ${ident( type )}`;
        }
    }
    else if ( type.kind === SyntaxKind.TypeLiteral )
    {
<<<<<<< HEAD
        const tl = type.members.length;

        return !tl ? '{}' : tl === 1 ? `{ ${add_types( type.members[ 0 ] )}` : `{ ${type.members.map( add_types ).join( ', ' )} }`;
    }
    else if ( type.kind === SyntaxKind.IndexSignature )
        return `[ ${type.parameters.map( add_types ).join( ', ' )} ]: ${add_types( type.type )} }`;

    else if ( type.kind === SyntaxKind.Parameter )
        return `${add_types( type.name )}: ${add_types( type.type )}`;
    else if ( type.kind === SyntaxKind.TupleType )
        return `[ ${type.elementTypes.map( add_types ).join( ', ' )} ]`;
=======
        const tl = show_sym( type.symbol );
        Object.defineProperty( tl, 'toString', { enumerable: false, value: () => type_literal_as_string( tl.members ) } );
        return tl;
    }
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac
    else
        t = type && !type.types ? get_type_name( type ) : type && type.types ? type.types.map( get_type_name ).join( ' | ' ) : '';

    if ( /^\s*[A-Z][a-z]+Keyword\s*$/.test( t ) )
        t = t.replace( /^\s*(.*)Keyword\s*$/, '$1' ).toLowerCase();

    if ( type.kind === SyntaxKind.TypeParameter && type.constraint )
    {
        let typeOp = type_in_mapped_type( type ) ? ' in' : ' extends',
            tn;

        if ( type.constraint.kind === SyntaxKind.TypeOperator )
        {
            typeOp += ' keyof';
            tn = get_type_name( type.constraint.type );
        }
        else
            tn = get_type_name( type.constraint );

        t += `${typeOp} ${tn}`;
    }

    t += check_for_template( type );

    return t;
}

function check_for_template( type )
{
    if ( type.typeParameters )
        return type_parameters( type.typeParameters );

    if ( type.typeArguments )
        return type_parameters( type.typeArguments );

    return '';
}

function get_type_name( type )
{
    if ( !type ) return '<no type name>';

    let typeName = type.typeName && type.typeName.escapedText ?
                   type.typeName.escapedText :
                   type.name && type.name.escapedText ? type.name.escapedText :
                   type.exprName ? type.exprName.escapedText :
                   type.kind ?
                   SyntaxKind[ type.kind ] :
                   '';

    if ( /^\s*[A-Z][a-z]+Keyword\s*$/.test( typeName ) )
        typeName = typeName.replace( /^(.*)Keyword$/, '$1' ).toLowerCase();

    if ( typeName === 'IndexedAccessType' )
<<<<<<< HEAD
        return get_type_name( type.objectType ) + '[' + get_type_name( type.indexType ) + ']' + ident( type );
=======
        return get_type_name( type.objectType ) + '[' + get_type_name( type.indexType ) + ']';
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    typeName += check_for_template( type );

    if ( typeName === 'ArrayType' && type.elementType ) typeName = add_types( type.elementType ) + '[]';

    return typeName;

}

function type_parameters( tp )
{
    if ( !tp || !tp.length ) return '';

    return `<${tp.map( add_types ).join( ', ' )}>`;
}

function disambiguate( name )
{
    return typeof name === 'string' && !( {}[ name ] ) ? name : ( '__' + name );
}

/**
 * @param {ts.QualifiedName} node
 */
function qual_name( node )
{
    if ( SyntaxKind.Identifier === node.kind )
        return node.escapedText + ident( node );
    else if ( SyntaxKind.QualifiedName === node.kind )
        return qual_name( node.left ) + '.' + qual_name( node.right );

    console.error( `Unexpected kind in qualified name: ${SyntaxKind[ node.kind ]}` );
    return 'unknown';
}

function func_type( type )
{
    if ( type.parameters.length )
        return `${type_parameters( type.typeParameters )}( ${type.parameters.map( pretty ).join( ', ' )} ) => ${add_types( type.type )}`;
    else if ( !type.parameters || !type.parameters.length )
        return `${type_parameters( type.typeParameters )}() => ${add_types( type.type )}`;
}

function func_type_info( type, dd )
{
    if ( type.typeParameters && type.typeParameters.length )
        dd.typeParameters = type.typeParameters.map( add_types );

    if ( type.parameters && type.parameters.length )
        dd.parameters = type.parameters.map( add_param );
}

function add_param( decl )
{

    const p = add_raw_types( decl.type ) || {};
    p.name =  decl.name && decl.name.escapedText || 'anon';

    if ( decl.dotDotDotToken )
        p.rest = true;

    return optional( p, decl.questionToken );
}

function raw_literal( type )
{
    switch ( type.literal.kind )
    {
        case SyntaxKind.StringLiteral:
            return { type: 'literal', ltype: 'string', value: type.literal.text };

        case SyntaxKind.NumericLiteral:
            return { type: 'literal', ltype: 'number', value: type.literal.text };

        case SyntaxKind.TrueKeyword:
            return { type: 'literal', ltype: 'boolean', value: true };

        case SyntaxKind.FalseKeyword:
            return { type: 'literal', ltype: 'boolean', value: false };

        default:
            return `Unknown literal "${SyntaxKind[ type.literal.kind ]}"`;
    }
}

/**
 * @param {ts.Node} type
 * @return {{}|[]|void}
 */
function add_raw_types( type )
{
    // if ( !type ) return '<missing> ' + new Error().stack.split( /\r?\n/ ).slice( 1, 4 ).join( ' | ' );

    let t = {};

    switch ( type.kind )
    {
        case SyntaxKind.Identifier:
            return type.escapedText;

        case SyntaxKind.ParenthesizedType:
            return { type: 'parens', types: add_raw_types( type.type ) };

        case SyntaxKind.TypePredicate:
            return { type: 'predicate', param: type.parameterName.escapedText, returns: add_raw_types( type.type ) };

        case SyntaxKind.TypeReference:
            const
                r = {
                    type: add_raw_types( type.typeName )
                },
                tmpl = check_for_raw_template( type );

            if ( tmpl )
                r.template = fix_raw_templates( tmpl );

            return r;

        case SyntaxKind.QualifiedName:
            return { type: 'qualified', names: qual_raw_name( type ) };

        case SyntaxKind.FunctionType:
            return func_type_info( type, { type: 'function' } );

        case SyntaxKind.UnionType:
            return { type: 'union', types: type.types.map( add_raw_types ) };

        case SyntaxKind.IntersectionType:
            return { type: 'intersection', types: type.types.map( add_raw_types ) };

        case SyntaxKind.MappedType:
            const mapped = {
                type: 'mapped',
                name: null
            };

            if ( type.questionToken ) mapped.optional = true;
            mapped.name = get_raw_type_name( type.type );

            return mapped;

        case SyntaxKind.LiteralType:
            return raw_literal( type );

        case SyntaxKind.TypeLiteral:
            return {
                type: 'type',
                members: type.members.map( add_raw_types )
            };

        case SyntaxKind.IndexSignature:
            return {
                type: 'index',
                typeName: elevate( add_raw_types( type.type ) ),
                parameters: type.parameters.map( add_raw_types )
            };

        case SyntaxKind.Parameter:
            const typeList = elevate( clean( add_raw_types( type.type ) ) );

            return optional( {
                name: add_raw_types( type.name ),
                type: typeList
            }, type.questionToken );

        case SyntaxKind.TupleType:
            return {
                type: 'tuple',
                types: type.elementTypes.map( add_raw_types ).map( elevate )
            };

    }

    if ( type )
        t = !type.types ? get_raw_type_name( type ) : type.types.map( get_raw_type_name );

    if ( !isObject( t ) )
        t = { type: t };
    else if ( isObject( t.typeName ) )
    {
        const keys = Object.keys( t.typeName );

        if ( keys.length === 1 && keys[ 0 ] === 'type' )
        {
            t.type = t.typeName.type;
            delete t.typeName;
        }
    }

    t.types = fixKeyword( t.types );

    if ( type.kind === SyntaxKind.TypeParameter && type.constraint )
    {
        t.typeOperator = type_in_mapped_type( type ) ? ' in' : ' extends';

        if ( type.constraint.kind === SyntaxKind.TypeOperator )
        {
            t.keyOf = true;
            t.typeName = get_raw_type_name( type.constraint.type );
        }
        else
            t.typeName = get_raw_type_name( type.constraint );
    }

    const tmpl = check_for_raw_template( type );

    if ( tmpl ) t.template = fix_raw_templates( tmpl );

    if ( t.type ) t.type = elevate( t.type );

    return t;
}

/**
 * @param tmpl
 * @return {*}
 */
function fix_raw_templates( tmpl )
{
    if ( Array.isArray( tmpl ) )
        return tmpl.map( elevate );
    else if ( isObject( tmpl ) )
    {
        const tk = Object.keys( tmpl );

        if ( tk.length !== 1 )
            tk.forEach( k => tmpl[ k ] = fix_raw_templates( tmpl[ k ] ) );
    }

    return tmpl;
}

/**
 * @param {ts.QualifiedName} node
 */
function qual_raw_name( node )
{
    if ( SyntaxKind.Identifier === node.kind )
        return [ node.escapedText ];
    else if ( SyntaxKind.QualifiedName === node.kind )
        return qual_raw_name( node.left ).concat( qual_raw_name( node.right ) );
}

function check_for_raw_template( type )
{
    if ( type.typeParameters )
        return type_raw_parameters( type.typeParameters );

    if ( type.typeArguments )
        return type_raw_parameters( type.typeArguments );

    return '';
}

function get_raw_type_name( type )
{
    if ( !type ) return '<no type name>';

    let typeName = type.typeName && type.typeName.escapedText ?
                   type.typeName.escapedText :
                   type.name && type.name.escapedText ? type.name.escapedText :
                   type.exprName ? type.exprName.escapedText :
                   type.kind ?
                   SyntaxKind[ type.kind ] :
                   '';

    if ( /^\s*[A-Z][a-z]+Keyword\s*$/.test( typeName ) )
        typeName = typeName.replace( /^(.*)Keyword$/, '$1' ).toLowerCase();

    const r = {
        typeName
    };

    if ( typeName === 'IndexedAccessType' )
    {
        r.indexType = get_raw_type_name( type.indexType );
        r.typeName = get_raw_type_name( type.objectType );
        return r;
    }

    const tmpl = check_for_raw_template( type );
    if ( tmpl )
        r.template = fix_raw_templates( tmpl );

    if ( typeName === 'ArrayType' && type.elementType )
    {
        r.typeName = add_raw_types( type.elementType );
        r.isArray = true;
    }

    return r;

}

function type_raw_parameters( tp )
{
    if ( !tp || !tp.length ) return null;

    return tp.map( add_raw_types );
}

