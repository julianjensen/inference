/// <reference path="modules/doctrine/index.d.ts" />
/// <reference path="modules/esprima/index.d.ts" />
/// <reference path="modules/estraverse/index.d.ts" />
/// <reference path="modules/estree/index.d.ts" />
