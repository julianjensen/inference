/** ******************************************************************************************************************
 * @file cli.js version
 * @author Julian Jensen <jjdanois@gmail.com>
 * @since 1.0.0
 * @date 19-Jan-2018
 *********************************************************************************************************************/


"use strict";

import program from 'commander';

import Parser from "./src/utils/parser";
import globals from './src/utils/globals';
import { create_symbols } from "./src/symbols/simple-table";

const
    pack           = require( './package.json' ),
    version        = pack.version,
    name           = pack.name,
    $              = o => JSON.stringify( o, null, 4 ),
    defaultOptions = {
        loc: true,
        range: true,
        comment: true,
        tokens: true,
        ecmaVersion: 9,
        sourceType: 'module',
        ecmaFeatures: {
            impliedStrict: true,
            experimentalObjectRestSpread: true
        }
    };

program
    .version( version )
    .name( name )
    .description( 'Parse JavaScript files and extract JsDoc tags' )
    .usage( name + ' [files...]' )
    .option( '-s, --script', 'Process file(s) as script files', false )
    .option( '[files...]' )
    .parse( process.argv );

if ( !program.args.length ) program.help();

globals.program = program;

<<<<<<< HEAD
( async() => {
    const
        parser = new Parser( [ 'data' ] );
=======
    const outp = ts.map( file => walk_symbols( file ) ); // sym_walk( file.ast ) );

    console.log( $( outp ) );
    // reportStatistics();
}

// new Promise( ( resolve, reject ) => {
//     let ref = 2;
//     const
//         reader   = read_files( tsFiles ),
//         compiler = compile_files( reader ),
//         sub      = reader.subscribe( {
//             next( obj )
//             {
//                 console.log( `name: ${obj.filename}` );
//                 console.log( `source? ${!!obj.source}` );
//             },
//             error: reject,
//             complete()
//             {
//                 sub.unsubscribe();
//                 --ref;
//                 if ( ref <= 0 ) resolve( 'okay' );
//             }
//         } ),
//         csub     = compiler.subscribe( {
//             next( file )
//             {
//                 console.log( `compiled: ${file.filename}, ast? ${!!file.ast}, is ` );
//             },
//             error: reject,
//             complete()
//             {
//                 csub.unsubscribe();
//                 --ref;
//                 if ( ref <= 0 ) resolve( "comp'd" );
//             }
//         } );
//
// } )
//     .catch( err => console.error( err ) )
//     .then( status => console.log( status ) );


run_all();


/**
 * @param {Array<string>} files
 * @return {*[]}
 */
async function parse_ts( files )
{
    if ( files.length )
    {
        settings.loadParser();
        return await settings.aparse( files );
    }

    return [];
}

/**
 * @param {Array<string>} files
 * @return {*[]}
 */
async function parse_js( files )
{
    defaultOptions.sourceType = program.script ? 'script' : 'module';

    if ( files.length )
    {
        return files.map( async filename => {
            const
                source = await concurrent.readFile( filename, 'utf8' ),
                ast    = parse( source, defaultOptions );

            return {
                filename,
                source,
                ast
            };
        } );
    }

    return [];
}
>>>>>>> 07e0a9f7fc435c8e8843c7a3a257a53b45cbd7ac

    await parser.add_source_files( ...program.args );
    await parser.parse();

    globals.file = parser.ambient;
    create_symbols( parser.ambientTypes );
    // console.log( $( parser.ambientTypes ) );
} )();
